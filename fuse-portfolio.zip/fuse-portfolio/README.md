# FUSE — Freelance Unified Skills & Experts

FUSE is a portfolio website for a collaborative freelance team offering remote sales, marketing, and creative support: lead generation, cold calling, social media, graphic design, video editing, data & admin support, basic GoHighLevel (GHL) support, and real estate support.

FUSE is a **team of freelancers**, not an agency, company, or corporation — the site's copy is written to reflect that throughout.

This is a static site (HTML, CSS, vanilla JavaScript) with no backend, built to run on **GitHub Pages**.

---

## Project structure

```
fuse-portfolio/
│
├── index.html          Main page — all sections live here
├── style.css            All styling
├── script.js             Navigation, animations, portfolio filtering & modal
├── README.md
│
└── assets/
    ├── team/             Team member photos
    ├── portfolio/        Portfolio images (graphic design, social, presentations, real estate)
    └── videos/           Video thumbnail images
```

Placeholder images (light-blue gradient SVGs) are already in place so the site works immediately. Replace them with real photos/graphics whenever you're ready — no code changes required as long as you keep the same file names, or update the paths as described below.

---

## Replacing team photos

1. Add your photo to `assets/team/`, named after the person, e.g. `kithana.jpg`.
2. Open `index.html`, find the team member's card (search for their name), and update the `src`:

```html
<img src="assets/team/kithana.svg" alt="Portrait of Kithana" loading="lazy">
```

becomes:

```html
<img src="assets/team/kithana.jpg" alt="Portrait of Kithana" loading="lazy">
```

Recommended photo ratio: **4:5** (portrait), at least 800×1000px.

---

## Replacing portfolio images

All portfolio content is defined in one place: the `PORTFOLIO_ITEMS` array near the top of `script.js`.

```js
{ id: 'p01', img: 'assets/portfolio/design-01.svg', title: 'Social Post Series', category: 'Graphic Design', desc: '...' },
```

To replace an image or update its details:

1. Add your image file to `assets/portfolio/`.
2. Update the `img` path in the matching object.
3. Update `title`, `category`, and `desc` as needed.
4. To mark an item as a video (adds a play icon), add `video: true` to that object.

To add a brand-new portfolio item, copy an existing object, give it a unique `id`, and fill in the details. It will automatically appear in the grid and respect the category filters.

**Categories currently used:** `Graphic Design`, `Social Media`, `Video Editing`, `Presentations`, `Real Estate`. If you use a new category name, also add a matching filter button in the `.portfolio-filters` section of `index.html`.

---

## Replacing video thumbnails

Video thumbnail images live in `assets/videos/` and are referenced from the same `PORTFOLIO_ITEMS` list in `script.js` (items with `video: true`). The site currently shows thumbnail + play icon; wiring up actual video playback (e.g. embedding YouTube/Vimeo or an HTML5 `<video>`) can be done inside the `openModalById` function in `script.js` if you want the modal to play video instead of showing a static image.

---

## Updating contact information

Open `index.html` and search for the **Final CTA** section (`id="contact"`) and the **footer**. Update:

```html
<a href="mailto:hello@fuseteam.example" class="contact-item">
  ...
  <span class="contact-value">hello@fuseteam.example</span>
</a>
<a href="https://wa.me/10000000000" class="contact-item">
  ...
</a>
```

Replace the email address and the WhatsApp link (`https://wa.me/<your number with country code, no spaces or symbols>`). The same links are repeated in the footer — update both.

---

## Customizing colors

All colors are defined as CSS variables at the top of `style.css`:

```css
:root {
  --blue-light: #8ED8F8;
  --blue-accent: #39AEEA;
  --dark: #0B1724;
  --white: #FFFFFF;
  --bg-soft: #F4FBFF;
}
```

Change any value here and it updates across the entire site.

---

## Customizing team information

Team member cards are in `index.html` inside the `<section id="team">` block. Each card follows this structure:

```html
<article class="team-card reveal-up">
  <div class="team-photo"><img src="assets/team/name.jpg" alt="Portrait of Name" loading="lazy"></div>
  <div class="team-info">
    <h3>Name</h3>
    <p class="team-specialty">Specialty One · Specialty Two</p>
    <p class="team-desc">Short description of what this person does.</p>
    <p class="team-tools">Tool · Tool · Tool</p>
  </div>
</article>
```

To add or remove a team member, copy/remove one of these `<article class="team-card">` blocks.

---

## Deploying on GitHub Pages

1. Create a new GitHub repository (public, unless you have GitHub Pages available on private repos).
2. Upload the contents of this `fuse-portfolio/` folder to the repository root (or push via git).
3. In the repository, go to **Settings → Pages**.
4. Under **Build and deployment**, set **Source** to "Deploy from a branch".
5. Choose the branch (usually `main`) and folder `/ (root)`, then save.
6. GitHub will publish the site at `https://<your-username>.github.io/<repository-name>/`.
7. Wait a minute or two, then visit the URL to confirm it works.

All file paths in this project are relative, so the site works correctly whether it's hosted at the root of a domain or inside a subfolder like GitHub Pages project sites.

---

## Notes

- No build step, no npm install, no backend — just open `index.html` in a browser to preview locally, or use a simple local server (e.g. the VS Code "Live Server" extension) for the smoothest experience with relative paths.
- The site respects `prefers-reduced-motion` for visitors who prefer minimal animation.
- Portfolio filtering, the lightbox modal, the mobile menu, and scroll animations are all handled in `script.js` with no external libraries.

---

© 2026 FUSE — Freelance Unified Skills & Experts
